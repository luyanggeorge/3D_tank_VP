======================================
                Summary               
======================================

------ Dimensions of the domain ------
Length Lx:     6.5000 m
Length Ly:     1.0000 m
Depth  H0:     1.0000 m
Beach start:    4.0 m
Beach slope:    0.2

----------- Mesh resolution ----------
In x:     0.0500 m (130   elements)
In y:     0.0500 m (20    elements)
In z:     9 layers

-------------- Wavemaker -------------
Amplitude:     0.0300 m
Period:        1.1339 s
Frequency:     5.5411 s-1
Stops after   5.00 periods (  5.6696 s)
Lw:           1.0 m

--------------- Solver ---------------
2nd order Modified Mid-Point scheme

------------- Final time -------------
Tend:     0.0200 s
Δt:       0.0010 s
Before time loop: 27.33 s
Computation time: 0  d 0  h 9  min 26.6 s
That is in total:   566.5593 s
